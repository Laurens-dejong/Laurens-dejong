﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.XPath;

namespace rekenmachine_opdracht_v2
{
    public partial class frmRekenmachine : System.Windows.Forms.Form
    {



        public frmRekenmachine()
        {
            InitializeComponent();
        }
        float num1, ans;
        int count;

        private void btn1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "1";            // voegt een 1 toe aan het scherm en aan de berekening
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "2";             // voegt een 2 toe aan het scherm en aan de berekening
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "3";             // voegt een 3 toe aan het scherm en aan de berekening
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "4";             // voegt een 4 toe aan het scherm en aan de berekening
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "5";             // voegt een 5 toe aan het scherm en aan de berekening
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "6";             // voegt een 6 toe aan het scherm en aan de berekening
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "7";             // voegt een 7 toe aan het scherm en aan de berekening
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "8";             // voegt een 8 toe aan het scherm en aan de berekening
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "9";             // voegt een 9 toe aan het scherm en aan de berekening
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "0";             // voegt een 0 toe aan het scherm en aan de berekening
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            count = 0;                      // verwijderd de som en alles op het scherm zodat je 
        }                                   // weer opnieuw kan beginnen 

        private void btnAntwoord_Click(object sender, EventArgs e)
        {
            compute(count);
        }
        public void compute(int count)
        {
            switch (count)
            {
                case 1:
                    ans = num1 - float.Parse(txtDisplay.Text); // kijkt of er - word geselecteerd
                    txtDisplay.Text = ans.ToString();
                    break;
                case 2:
                    ans = num1 + float.Parse(txtDisplay.Text); // kijkt of er + word geselecteerd
                    txtDisplay.Text = ans.ToString();
                    break;
                case 3:
                    ans = num1 * float.Parse(txtDisplay.Text); // kijkt of er * word geselecteerd
                    txtDisplay.Text = ans.ToString();
                    break;
                case 4:
                    ans = num1 / float.Parse(txtDisplay.Text); // kijkt of er / word geselecteerd
                    txtDisplay.Text = ans.ToString();
                    break;
                default:
                    break;
            }
        }

        private void btnGedeeldDoor_Click(object sender, EventArgs e)
        {
            num1 = float.Parse(txtDisplay.Text);
            txtDisplay.Clear();                     // als gedeeld door word geselecteerd dan gaat de code de code gebruiken van case 4
            txtDisplay.Focus();
            count = 4;
        }

        private void btnKeer_Click(object sender, EventArgs e) 
        {
            num1 = float.Parse(txtDisplay.Text);
            txtDisplay.Clear();                     // als keer word geselecteerd dan gaat de code de code gebruiken van case 3
            txtDisplay.Focus();
            count = 3;
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text != "")
            {
                num1 = float.Parse(txtDisplay.Text);
                txtDisplay.Clear();                  // als min word geselecteerd dan gaat de code de code gebruiken van case 1
                txtDisplay.Focus();
                count = 1;
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            num1 = float.Parse(txtDisplay.Text);
            txtDisplay.Clear();                  // als plus word geselecteerd dan gaat de code de code gebruiken van case 2
            txtDisplay.Focus();
            count = 2;
        }

        private void btnComma_Click(object sender, EventArgs e)
        {
            int c = txtDisplay.TextLength;
            int flag = 0;
            string text = txtDisplay.Text;
            for (int i = 0; i < c; i++)
            {
                if (text[i].ToString() == ".")
                {
                    flag = 1; break;
                }
                else                                 // als er een comma word geselecteerd dan gaat 
                {                                    // dit stuk code de comma toe voegen aan de berekening
                    flag = 0;
                }
            }
            if (flag == 0)
            {
                txtDisplay.Text = txtDisplay.Text + ".";
            }
        }

        private void txtDisplay_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
