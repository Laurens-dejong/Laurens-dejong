﻿namespace dierenarts_Laurens_de_Jong
{
    partial class frmInloggen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInloggen));
            this.btnInloggen = new System.Windows.Forms.Button();
            this.txtGebruikersnaam = new System.Windows.Forms.TextBox();
            this.txtWachtwoord = new System.Windows.Forms.TextBox();
            this.lblGebruikersnaam = new System.Windows.Forms.Label();
            this.lblWachtwoord = new System.Windows.Forms.Label();
            this.chbWachtwoordTonen = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnInloggen
            // 
            this.btnInloggen.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold);
            this.btnInloggen.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnInloggen.Location = new System.Drawing.Point(81, 215);
            this.btnInloggen.Name = "btnInloggen";
            this.btnInloggen.Size = new System.Drawing.Size(222, 57);
            this.btnInloggen.TabIndex = 0;
            this.btnInloggen.Text = "inloggen";
            this.btnInloggen.UseVisualStyleBackColor = true;
            this.btnInloggen.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtGebruikersnaam
            // 
            this.txtGebruikersnaam.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGebruikersnaam.Location = new System.Drawing.Point(51, 59);
            this.txtGebruikersnaam.MaxLength = 32;
            this.txtGebruikersnaam.Multiline = true;
            this.txtGebruikersnaam.Name = "txtGebruikersnaam";
            this.txtGebruikersnaam.Size = new System.Drawing.Size(285, 48);
            this.txtGebruikersnaam.TabIndex = 1;
            this.txtGebruikersnaam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtWachtwoord
            // 
            this.txtWachtwoord.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.8F);
            this.txtWachtwoord.Location = new System.Drawing.Point(51, 145);
            this.txtWachtwoord.MaxLength = 32;
            this.txtWachtwoord.Multiline = true;
            this.txtWachtwoord.Name = "txtWachtwoord";
            this.txtWachtwoord.PasswordChar = '●';
            this.txtWachtwoord.Size = new System.Drawing.Size(285, 48);
            this.txtWachtwoord.TabIndex = 2;
            this.txtWachtwoord.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblGebruikersnaam
            // 
            this.lblGebruikersnaam.AutoSize = true;
            this.lblGebruikersnaam.BackColor = System.Drawing.Color.Transparent;
            this.lblGebruikersnaam.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.8F, System.Drawing.FontStyle.Bold);
            this.lblGebruikersnaam.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblGebruikersnaam.Location = new System.Drawing.Point(46, 27);
            this.lblGebruikersnaam.Name = "lblGebruikersnaam";
            this.lblGebruikersnaam.Size = new System.Drawing.Size(212, 29);
            this.lblGebruikersnaam.TabIndex = 3;
            this.lblGebruikersnaam.Text = "Gebruikersnaam:";
            // 
            // lblWachtwoord
            // 
            this.lblWachtwoord.AutoSize = true;
            this.lblWachtwoord.BackColor = System.Drawing.Color.Transparent;
            this.lblWachtwoord.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.8F, System.Drawing.FontStyle.Bold);
            this.lblWachtwoord.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblWachtwoord.Location = new System.Drawing.Point(46, 113);
            this.lblWachtwoord.Name = "lblWachtwoord";
            this.lblWachtwoord.Size = new System.Drawing.Size(160, 29);
            this.lblWachtwoord.TabIndex = 4;
            this.lblWachtwoord.Text = "wachtwoord:";
            // 
            // chbWachtwoordTonen
            // 
            this.chbWachtwoordTonen.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chbWachtwoordTonen.Appearance = System.Windows.Forms.Appearance.Button;
            this.chbWachtwoordTonen.BackColor = System.Drawing.Color.White;
            this.chbWachtwoordTonen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chbWachtwoordTonen.BackgroundImage")));
            this.chbWachtwoordTonen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chbWachtwoordTonen.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbWachtwoordTonen.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.chbWachtwoordTonen.FlatAppearance.BorderSize = 0;
            this.chbWachtwoordTonen.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.chbWachtwoordTonen.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.chbWachtwoordTonen.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.chbWachtwoordTonen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chbWachtwoordTonen.ForeColor = System.Drawing.Color.White;
            this.chbWachtwoordTonen.Image = ((System.Drawing.Image)(resources.GetObject("chbWachtwoordTonen.Image")));
            this.chbWachtwoordTonen.Location = new System.Drawing.Point(278, 149);
            this.chbWachtwoordTonen.Name = "chbWachtwoordTonen";
            this.chbWachtwoordTonen.Size = new System.Drawing.Size(58, 40);
            this.chbWachtwoordTonen.TabIndex = 5;
            this.chbWachtwoordTonen.Text = "     ";
            this.chbWachtwoordTonen.UseVisualStyleBackColor = false;
            this.chbWachtwoordTonen.CheckedChanged += new System.EventHandler(this.chbWachtwoordTonen_CheckedChanged);
            // 
            // frmInloggen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(382, 514);
            this.Controls.Add(this.chbWachtwoordTonen);
            this.Controls.Add(this.lblWachtwoord);
            this.Controls.Add(this.lblGebruikersnaam);
            this.Controls.Add(this.txtWachtwoord);
            this.Controls.Add(this.txtGebruikersnaam);
            this.Controls.Add(this.btnInloggen);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Name = "frmInloggen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dierenarts inloggen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInloggen;
        private System.Windows.Forms.TextBox txtGebruikersnaam;
        private System.Windows.Forms.TextBox txtWachtwoord;
        private System.Windows.Forms.Label lblGebruikersnaam;
        private System.Windows.Forms.Label lblWachtwoord;
        private System.Windows.Forms.CheckBox chbWachtwoordTonen;
    }
}

