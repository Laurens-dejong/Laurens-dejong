﻿namespace dierenarts_Laurens_de_Jong
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.grbKlantgegevens = new System.Windows.Forms.GroupBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnVerwijderen = new System.Windows.Forms.Button();
            this.btnWijzigen = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnInvoeren = new System.Windows.Forms.Button();
            this.lblVoorletters = new System.Windows.Forms.Label();
            this.txtWoonplaats = new System.Windows.Forms.TextBox();
            this.txtAdres = new System.Windows.Forms.TextBox();
            this.txtAchternaam = new System.Windows.Forms.TextBox();
            this.txtVoorletters = new System.Windows.Forms.TextBox();
            this.lblAantalItems = new System.Windows.Forms.Label();
            this.lbxOverzicht = new System.Windows.Forms.ListBox();
            this.lblAantalBehandelingen = new System.Windows.Forms.Label();
            this.btnUitloggen = new System.Windows.Forms.Button();
            this.grbKlantgegevens.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbKlantgegevens
            // 
            this.grbKlantgegevens.BackColor = System.Drawing.Color.Transparent;
            this.grbKlantgegevens.Controls.Add(this.btnRefresh);
            this.grbKlantgegevens.Controls.Add(this.btnVerwijderen);
            this.grbKlantgegevens.Controls.Add(this.btnWijzigen);
            this.grbKlantgegevens.Controls.Add(this.label3);
            this.grbKlantgegevens.Controls.Add(this.label2);
            this.grbKlantgegevens.Controls.Add(this.label1);
            this.grbKlantgegevens.Controls.Add(this.btnInvoeren);
            this.grbKlantgegevens.Controls.Add(this.lblVoorletters);
            this.grbKlantgegevens.Controls.Add(this.txtWoonplaats);
            this.grbKlantgegevens.Controls.Add(this.txtAdres);
            this.grbKlantgegevens.Controls.Add(this.txtAchternaam);
            this.grbKlantgegevens.Controls.Add(this.txtVoorletters);
            this.grbKlantgegevens.Location = new System.Drawing.Point(379, 10);
            this.grbKlantgegevens.Margin = new System.Windows.Forms.Padding(2);
            this.grbKlantgegevens.Name = "grbKlantgegevens";
            this.grbKlantgegevens.Padding = new System.Windows.Forms.Padding(2);
            this.grbKlantgegevens.Size = new System.Drawing.Size(416, 211);
            this.grbKlantgegevens.TabIndex = 0;
            this.grbKlantgegevens.TabStop = false;
            this.grbKlantgegevens.Text = "Klant gegevens";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.btnRefresh.ForeColor = System.Drawing.Color.Black;
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.Location = new System.Drawing.Point(326, 132);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(2);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(77, 33);
            this.btnRefresh.TabIndex = 9;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnVerwijderen
            // 
            this.btnVerwijderen.BackColor = System.Drawing.Color.Red;
            this.btnVerwijderen.Font = new System.Drawing.Font("MV Boli", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerwijderen.Location = new System.Drawing.Point(269, 170);
            this.btnVerwijderen.Margin = new System.Windows.Forms.Padding(2);
            this.btnVerwijderen.Name = "btnVerwijderen";
            this.btnVerwijderen.Size = new System.Drawing.Size(134, 37);
            this.btnVerwijderen.TabIndex = 2;
            this.btnVerwijderen.Text = "verwijderen";
            this.btnVerwijderen.UseVisualStyleBackColor = false;
            this.btnVerwijderen.Click += new System.EventHandler(this.btnVerwijderen_Click);
            // 
            // btnWijzigen
            // 
            this.btnWijzigen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnWijzigen.Font = new System.Drawing.Font("MV Boli", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWijzigen.Location = new System.Drawing.Point(147, 170);
            this.btnWijzigen.Margin = new System.Windows.Forms.Padding(2);
            this.btnWijzigen.Name = "btnWijzigen";
            this.btnWijzigen.Size = new System.Drawing.Size(117, 37);
            this.btnWijzigen.TabIndex = 1;
            this.btnWijzigen.Text = "wijzigen";
            this.btnWijzigen.UseVisualStyleBackColor = false;
            this.btnWijzigen.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(0, 141);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 24);
            this.label3.TabIndex = 8;
            this.label3.Text = "Woonplaats";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(63, 103);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "Adres";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(-1, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "Achternaam";
            // 
            // btnInvoeren
            // 
            this.btnInvoeren.BackColor = System.Drawing.Color.Lime;
            this.btnInvoeren.Font = new System.Drawing.Font("MV Boli", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnInvoeren.Location = new System.Drawing.Point(14, 170);
            this.btnInvoeren.Margin = new System.Windows.Forms.Padding(2);
            this.btnInvoeren.Name = "btnInvoeren";
            this.btnInvoeren.Size = new System.Drawing.Size(127, 37);
            this.btnInvoeren.TabIndex = 0;
            this.btnInvoeren.Text = "invoeren";
            this.btnInvoeren.UseVisualStyleBackColor = false;
            this.btnInvoeren.Click += new System.EventHandler(this.btnInvoeren_Click);
            // 
            // lblVoorletters
            // 
            this.lblVoorletters.AutoSize = true;
            this.lblVoorletters.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoorletters.ForeColor = System.Drawing.Color.Black;
            this.lblVoorletters.Location = new System.Drawing.Point(9, 27);
            this.lblVoorletters.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVoorletters.Name = "lblVoorletters";
            this.lblVoorletters.Size = new System.Drawing.Size(111, 24);
            this.lblVoorletters.TabIndex = 5;
            this.lblVoorletters.Text = "Voorletters";
            // 
            // txtWoonplaats
            // 
            this.txtWoonplaats.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtWoonplaats.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWoonplaats.Location = new System.Drawing.Point(140, 132);
            this.txtWoonplaats.Margin = new System.Windows.Forms.Padding(2);
            this.txtWoonplaats.MaxLength = 32;
            this.txtWoonplaats.Multiline = true;
            this.txtWoonplaats.Name = "txtWoonplaats";
            this.txtWoonplaats.Size = new System.Drawing.Size(180, 34);
            this.txtWoonplaats.TabIndex = 4;
            this.txtWoonplaats.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAdres
            // 
            this.txtAdres.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdres.Location = new System.Drawing.Point(140, 93);
            this.txtAdres.Margin = new System.Windows.Forms.Padding(2);
            this.txtAdres.MaxLength = 32;
            this.txtAdres.Multiline = true;
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(180, 34);
            this.txtAdres.TabIndex = 3;
            this.txtAdres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAchternaam
            // 
            this.txtAchternaam.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtAchternaam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAchternaam.Location = new System.Drawing.Point(140, 55);
            this.txtAchternaam.Margin = new System.Windows.Forms.Padding(2);
            this.txtAchternaam.MaxLength = 32;
            this.txtAchternaam.Multiline = true;
            this.txtAchternaam.Name = "txtAchternaam";
            this.txtAchternaam.Size = new System.Drawing.Size(180, 34);
            this.txtAchternaam.TabIndex = 2;
            this.txtAchternaam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtVoorletters
            // 
            this.txtVoorletters.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtVoorletters.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVoorletters.Location = new System.Drawing.Point(140, 17);
            this.txtVoorletters.Margin = new System.Windows.Forms.Padding(2);
            this.txtVoorletters.MaxLength = 32;
            this.txtVoorletters.Multiline = true;
            this.txtVoorletters.Name = "txtVoorletters";
            this.txtVoorletters.Size = new System.Drawing.Size(180, 34);
            this.txtVoorletters.TabIndex = 1;
            this.txtVoorletters.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblAantalItems
            // 
            this.lblAantalItems.AutoSize = true;
            this.lblAantalItems.BackColor = System.Drawing.Color.Transparent;
            this.lblAantalItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAantalItems.ForeColor = System.Drawing.Color.Black;
            this.lblAantalItems.Location = new System.Drawing.Point(602, 223);
            this.lblAantalItems.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAantalItems.Name = "lblAantalItems";
            this.lblAantalItems.Size = new System.Drawing.Size(80, 55);
            this.lblAantalItems.TabIndex = 10;
            this.lblAantalItems.Text = "00";
            this.lblAantalItems.Click += new System.EventHandler(this.lblAantalItems_Click);
            // 
            // lbxOverzicht
            // 
            this.lbxOverzicht.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lbxOverzicht.FormattingEnabled = true;
            this.lbxOverzicht.Location = new System.Drawing.Point(11, 11);
            this.lbxOverzicht.Margin = new System.Windows.Forms.Padding(2);
            this.lbxOverzicht.Name = "lbxOverzicht";
            this.lbxOverzicht.Size = new System.Drawing.Size(363, 212);
            this.lbxOverzicht.TabIndex = 1;
            this.lbxOverzicht.SelectedIndexChanged += new System.EventHandler(this.lbxOverzicht_SelectedIndexChanged);
            // 
            // lblAantalBehandelingen
            // 
            this.lblAantalBehandelingen.AutoSize = true;
            this.lblAantalBehandelingen.BackColor = System.Drawing.Color.Transparent;
            this.lblAantalBehandelingen.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Bold);
            this.lblAantalBehandelingen.Location = new System.Drawing.Point(331, 236);
            this.lblAantalBehandelingen.Name = "lblAantalBehandelingen";
            this.lblAantalBehandelingen.Size = new System.Drawing.Size(278, 29);
            this.lblAantalBehandelingen.TabIndex = 11;
            this.lblAantalBehandelingen.Text = "Aantal behandelingen";
            // 
            // btnUitloggen
            // 
            this.btnUitloggen.BackColor = System.Drawing.Color.Bisque;
            this.btnUitloggen.Font = new System.Drawing.Font("MV Boli", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUitloggen.Location = new System.Drawing.Point(675, 228);
            this.btnUitloggen.Margin = new System.Windows.Forms.Padding(2);
            this.btnUitloggen.Name = "btnUitloggen";
            this.btnUitloggen.Size = new System.Drawing.Size(134, 37);
            this.btnUitloggen.TabIndex = 12;
            this.btnUitloggen.Text = "uitloggen";
            this.btnUitloggen.UseVisualStyleBackColor = false;
            this.btnUitloggen.Click += new System.EventHandler(this.btnUitloggen_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(820, 346);
            this.Controls.Add(this.btnUitloggen);
            this.Controls.Add(this.lblAantalItems);
            this.Controls.Add(this.lblAantalBehandelingen);
            this.Controls.Add(this.lbxOverzicht);
            this.Controls.Add(this.grbKlantgegevens);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(840, 389);
            this.MinimumSize = new System.Drawing.Size(840, 389);
            this.Name = "Form2";
            this.Text = "Dierenarts";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.grbKlantgegevens.ResumeLayout(false);
            this.grbKlantgegevens.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbKlantgegevens;
        private System.Windows.Forms.TextBox txtWoonplaats;
        private System.Windows.Forms.TextBox txtAdres;
        private System.Windows.Forms.TextBox txtAchternaam;
        private System.Windows.Forms.TextBox txtVoorletters;
        private System.Windows.Forms.Button btnInvoeren;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVoorletters;
        private System.Windows.Forms.Button btnWijzigen;
        private System.Windows.Forms.Button btnVerwijderen;
        private System.Windows.Forms.ListBox lbxOverzicht;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblAantalItems;
        private System.Windows.Forms.Label lblAantalBehandelingen;
        private System.Windows.Forms.Button btnUitloggen;
    }
}