﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Diagnostics.Eventing.Reader;

namespace dierenarts_Laurens_de_Jong
{
    public partial class frmInloggen : Form
    {
        public frmInloggen()
        {
            InitializeComponent();
        }
        //laurens de jong jlsd2
        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;data source = ..\\..\\..\\Dierenartsonline.accdb ";
            con.Open();
            OleDbDataReader dbread = null;

            string sql = "SELECT * FROM medewerker WHERE gebruikerid = " +
                "@gebruikerid AND wachtwoord = @wachtwoord";
            OleDbCommand dbcom = new OleDbCommand(sql, con);

            OleDbParameter param1 = new OleDbParameter();
            param1.ParameterName = "@gebruikerid";
            param1.Value = txtGebruikersnaam.Text;

            OleDbParameter param2 = new OleDbParameter();
            param2.ParameterName = "@wachtwoord";
            param2.Value = txtWachtwoord.Text;

            dbcom.Parameters.Add(param1);
            dbcom.Parameters.Add(param2);

            dbread = dbcom.ExecuteReader();

            if (dbread.HasRows)
            {
                MessageBox.Show("u bent ingelogd");
                Form2 frm = new Form2();    
                frm.Show();  //opent form 2 (dierenarts zelf)
                this.Hide(); //sluit de inlog pagina
            }
            else
            {
                MessageBox.Show("fout bij inloggen, controleer of uw " +
                 "gebruikersnaam en wachtwoord geen fouten bevatten");  //foutmelding voor als de gebruikersnaam of wachtwoord niet overeen komen
            }
        }

        private void chbWachtwoordTonen_CheckedChanged(object sender, EventArgs e)
        {
            txtWachtwoord.PasswordChar = chbWachtwoordTonen.Checked ? '\0' : '●'; 
            //als de check button in word geklikt veranderen de bolletjes in leesbare tekst, klik je er nog een keer op dan word het weer onleesbaar
        }
    }
}
