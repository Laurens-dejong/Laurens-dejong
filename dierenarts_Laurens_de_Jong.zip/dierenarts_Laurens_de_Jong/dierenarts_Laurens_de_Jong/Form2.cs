﻿using System;
using System.Data.OleDb;
using System.Diagnostics.Tracing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace dierenarts_Laurens_de_Jong
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        //laurens de jong jlsd2
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string woord = lbxOverzicht.SelectedItem.ToString();
                string[] woordenArray = woord.Split(' ');
                int klantid = int.Parse(woordenArray[0]);
                WijzigKlantGegevens(klantid);
            }
            catch {MessageBox.Show("probeer opnieuw");}
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            lblAantalItems.Text = lbxOverzicht.Items.Count.ToString();
            LeesGegevens();
        }
        private void LadenKlantDetails(int klantid)
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=..\\..\\..\\Dierenartsonline.accdb";
            con.Open();

            string sql = "SELECT * FROM klanten WHERE klantid = @klantid";
            OleDbCommand dbcom = new OleDbCommand(sql, con);

            OleDbParameter param1 = new OleDbParameter("@klantid", klantid);
            dbcom.Parameters.Add(param1);

            OleDbDataReader dbread = dbcom.ExecuteReader();

            if (dbread.Read())
            {
                txtVoorletters.Text = dbread["klantvoorletters"].ToString();
                txtAchternaam.Text = dbread["klantachternaam"].ToString();
                txtAdres.Text = dbread["klantadres"].ToString();
                txtWoonplaats.Text = dbread["klantwoonplaats"].ToString();
            }
            dbread.Close();
            dbcom.Dispose();
            con.Close();
        }
        public void KlantToevoegen()
        {
            try
            {
                string Voorletters = txtVoorletters.Text;
                string Achternaam = txtAchternaam.Text; //  + ",";
                string Adres = txtAdres.Text;
                string Woonplaats = txtWoonplaats.Text;

                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;data source = ..\\..\\..\\Dierenartsonline.accdb ";
                con.Open();

                string sql = "INSERT INTO klanten (klantvoorletters, klantachternaam, klantadres, " +
                "klantwoonplaats) VALUES (@klantvoorletters, @klantachternaam, @klantadres, " +
                "@klantwoonplaats)";
                OleDbCommand dbcom = new OleDbCommand(sql, con);

                dbcom.Parameters.AddWithValue("@klantvoorletters", Voorletters);
                dbcom.Parameters.AddWithValue("@klantachternaam", Achternaam);
                dbcom.Parameters.AddWithValue("@klantadres", Adres);
                dbcom.Parameters.AddWithValue("@klantwoonplaats", Woonplaats);

                dbcom.ExecuteReader();
                dbcom.Dispose();

                MessageBox.Show("Klant toegevoegd");
            }
            catch {MessageBox.Show("er gaat iets fout, probeer de klant opnieuw toe te voegen");}
        }
        private void btnInvoeren_Click(object sender, EventArgs e)
        {
            lbxOverzicht.Items.Clear();
            KlantToevoegen();
            LeesGegevens();
        }

        private void btnVerwijderen_Click(object sender, EventArgs e)
        {
            try
            {
                string woord = lbxOverzicht.SelectedItem.ToString();
                string[] woordenArray = woord.Split(' ');
                int klantid = int.Parse(woordenArray[0]);
                VerwijderKlant(klantid);

                lbxOverzicht.Items.Clear();
                LeesGegevens();
            }
            catch{MessageBox.Show("er gaat iets fout probeer de klant opnieuw te verwijderen");}
        }
        private void VerwijderKlant(int klantid)
        {
            try
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;data source = ..\\..\\..\\Dierenartsonline.accdb ";
                con.Open();
                string sql = "DELETE FROM Klanten WHERE klantid = @klantid";
                OleDbCommand dbcom = new OleDbCommand(sql, con);

                dbcom.Parameters.AddWithValue("@klantid", klantid);
                dbcom.ExecuteReader();
                dbcom.Dispose();

                MessageBox.Show("Klant verwijderd"); //melding om te laten weten dat de klant is verwijdert
            }
            catch {MessageBox.Show("er gaat iets fout probeer de klant opnieuw te verwijderen");} //melding om te laten weten dat het niet is gelukt 
        }
        public void AantalGegevens()
        {
            OleDbDataReader dbread = null;
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;data source = ..\\..\\..\\Dierenartsonline.accdb ";
            con.Open();
            string sql = "SELECT COUNT(*) AS totaal FROM klanten";
            OleDbCommand dbcom = new OleDbCommand(sql, con);
            dbread = dbcom.ExecuteReader();
            while (dbread.Read())
            {
                lblAantalItems.Text = dbread.GetValue(0).ToString();
            }
        }
        public void LeesGegevens()
        {
            OleDbDataReader dbread = null;
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;data source = ..\\..\\..\\Dierenartsonline.accdb ";
            con.Open();
            string sql = "SELECT * FROM klanten";
            OleDbCommand dbcom = new OleDbCommand(sql, con);
            dbread = dbcom.ExecuteReader();
            while (dbread.Read())
            {
                lbxOverzicht.Items.Add(dbread.GetValue(0).ToString() + " "
                + dbread.GetValue(1).ToString() + " " + 
                dbread.GetValue(2).ToString() + "" + ", " +
                dbread.GetValue(3).ToString());
            }
            dbread.Close();
            dbcom.Dispose();
            AantalGegevens();
        }
        public void WijzigKlantGegevens(int klantid)
        {
            try
            {
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;data source = ..\\..\\..\\Dierenartsonline.accdb ";
                con.Open();
                string sql = "UPDATE klanten SET klantvoorletters = @klantvoorletters, " +
                    "klantachternaam = @klantachternaam, " +
                    "klantadres = @klantadres, klantwoonplaats = @klantwoonplaats WHERE klantid = " +
                    "@klantid";
                OleDbCommand dbcom = new OleDbCommand(sql, con);
                dbcom.Parameters.AddWithValue("@klantvoorletters", txtVoorletters.Text);
                dbcom.Parameters.AddWithValue("@klantachternaam", txtAchternaam.Text); //update de klantgegevens met de ingevoerde data die de gebruiker
                dbcom.Parameters.AddWithValue("@klantadres", txtAdres.Text);           //in de tekstox heeft ingevoerd nadat de gebruiker de klant heeft geselecteerd in de listbox
                dbcom.Parameters.AddWithValue("@klantwoonplaats", txtWoonplaats.Text); 
                dbcom.Parameters.AddWithValue("@klantid", klantid);

                dbcom.ExecuteNonQuery();
                dbcom.Dispose();
                MessageBox.Show("Klantgegevens gewijzigd"); //melding om te laten weten dat het is gelukt
            }
            catch {MessageBox.Show("er gaat iets fout, probeer de klantgegevens opnieuw te wijzigen");}  //melding om te laten weten dat het is mislukt
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string Refresh = "";
            txtVoorletters.Text = Refresh;
            txtAchternaam.Text = Refresh; //zorgt ervoor dat de tekstboxen worden gevuld met niks (leegmaken)
            txtAdres.Text = Refresh;      //zodat de gebruiker weer nieuwe info in kan voeren
            txtWoonplaats.Text = Refresh;
        }

        private void lbxOverzicht_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string woord = lbxOverzicht.SelectedItem.ToString();
                string[] woordenArray = woord.Split(' ');
                int klantid = int.Parse(woordenArray[0]);

                LadenKlantDetails(klantid);
            }
            catch {MessageBox.Show("probeer opnieuw");}
        }

        private void lblAantalItems_Click(object sender, EventArgs e)
        {
            // --------------------------------------
        }

        private void btnUitloggen_Click(object sender, EventArgs e)
        {
            this.Close(); //als je op de uilog knop klikt dan word de applicatie dichtgedaan en kan de volgende gebruiker inloggen
            MessageBox.Show("je bent uitgelogd");
        }
    }
}


